package com.genpact.CMP_Automation.cmp;

import com.genpact.CMP_Automation.utility.AirWatchLoginUtil;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.IOException;

@RunWith(SpringJUnit4ClassRunner.class)
public class SysLogConnectionTest {
    @Test
    public void syslogTestConnection() throws InterruptedException, IOException {
        WebDriverManager.chromedriver().setup();

        WebDriver driver = new ChromeDriver();
        try {
            AirWatchLoginUtil.airWatchLogin(driver);
            WebElement groupsAndSettingsElement = AirWatchLoginUtil.webDriverWait(driver).until(ExpectedConditions.elementToBeClickable(By.id("settings_mainmenu")));
            groupsAndSettingsElement.click();

            WebElement allSettings = AirWatchLoginUtil.webDriverWait(driver).until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/main/section/nav/section[2]/ul[8]/li[1]/a")));
            allSettings.click();

            WebElement system = AirWatchLoginUtil.webDriverWait(driver).until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div[5]/div[2]/section/div/div[1]/div/h2[1]/a")));
            system.click();

            WebElement enterpriseIntegration = AirWatchLoginUtil.webDriverWait(driver).until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div[5]/div[2]/section/div/div[1]/div/ul[1]/li[3]/a[2]")));
            enterpriseIntegration.click();

            WebElement syslog = AirWatchLoginUtil.webDriverWait(driver).until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div[5]/div[2]/section/div/div[2]/div/div/div[2]/ul/li[12]/a")));
            syslog.click();

            WebElement testConnection = AirWatchLoginUtil.webDriverWait(driver).until(ExpectedConditions.elementToBeClickable(By.name("testSyslogConnection")));
            testConnection.click();

            WebElement testConnectionMsg = AirWatchLoginUtil.webDriverWait(driver).until(ExpectedConditions.elementToBeClickable(By.id("testSyslogConnectionMessage")));
            System.out.println(testConnectionMsg.getText());
            Assert.assertTrue(testConnectionMsg.getText().contains("successful"));

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            Runtime.getRuntime().exec("taskkill /F /IM ChromeDriver.exe");
            driver.quit();

        }

    }

}
