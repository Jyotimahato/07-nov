package com.genpact.CMP_Automation.cmp;

import com.genpact.CMP_Automation.model.Notifications;
import com.genpact.CMP_Automation.utility.AirWatchLoginUtil;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
public class MonitorConsoleNotificationTest {
    @Test
    public void monitorConsoleNotification() throws IOException {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        try {
            AirWatchLoginUtil.airWatchLogin(driver);
            WebElement notificationButton = AirWatchLoginUtil.webDriverWait(driver).until(ExpectedConditions.elementToBeClickable(By.id("notificationiconbtn")));
            notificationButton.click();

            WebElement notificationPanelContainer = AirWatchLoginUtil.webDriverWait(driver).until(ExpectedConditions.presenceOfElementLocated(By.id("notificationpanelContainer")));
            LocalDate today = LocalDate.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            String todayDate = today.format(formatter);

            AirWatchLoginUtil.webDriverWait(driver).until(ExpectedConditions.presenceOfElementLocated(By.className("notification__item")));
            List<WebElement> notifications = notificationPanelContainer.findElements(By.className("notification__item"));
            List<Notifications> foundNotifications = new ArrayList<>();
            for (WebElement notification : notifications) {
                List<WebElement> dateElements = notification.findElements(By.className("notification__item-datetime-value"));
                WebElement dataElement = notification.findElement(By.className("js-notification-content"));
                for (WebElement webElement : dateElements) {
                    if (webElement.getText().equals(todayDate)) {
                        Notifications notificationsDTO = new Notifications(dataElement.getText(), todayDate);
                        foundNotifications.add(notificationsDTO);
                    }

                }
            }
            System.out.println(foundNotifications);
            Assert.assertTrue(foundNotifications.isEmpty());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            Runtime.getRuntime().exec("taskkill /F /IM ChromeDriver.exe");
            driver.quit();
        }

    }

}
