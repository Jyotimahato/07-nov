package com.genpact.CMP_Automation.cmp;

import com.genpact.CMP_Automation.utility.AirWatchLoginUtil;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.IOException;

@RunWith(SpringJUnit4ClassRunner.class)
public class AppStorageQuotaCheckTest {
    @Test
    public void appStorageQuotaCheck() throws InterruptedException, IOException {
        WebDriverManager.chromedriver().setup();

        WebDriver driver = new ChromeDriver();
        try {
            AirWatchLoginUtil.airWatchLogin(driver);
            WebElement resourcesMainMenu = AirWatchLoginUtil.webDriverWait(driver).until(ExpectedConditions.elementToBeClickable(By.id("resources_mainmenu")));
            resourcesMainMenu.click();

            WebElement nativeAppAdd = AirWatchLoginUtil.webDriverWait(driver).until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/main/div/div/div[2]/div[2]/section[1]/div[1]/div[1]/section[2]/span[1]/a")));
            nativeAppAdd.click();

            WebElement applicationFile = AirWatchLoginUtil.webDriverWait(driver).until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/main/div/div/div[2]/div[2]/section[1]/div[1]/div[1]/section[2]/span[1]/div/div/a[1]")));
            applicationFile.click();

            WebElement uploadButton = AirWatchLoginUtil.webDriverWait(driver).until(ExpectedConditions.elementToBeClickable(By.id("uploadBtnApplicationFileBlobId")));
            uploadButton.click();

            WebElement storage = AirWatchLoginUtil.webDriverWait(driver).until(ExpectedConditions.presenceOfElementLocated(By.className("storage-used-indicator")));

            System.out.println(storage.getText());
            Assert.assertTrue(storage.getText().contains("You have used"));
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            Runtime.getRuntime().exec("taskkill /F /IM ChromeDriver.exe");
            driver.quit();

        }

    }

}
