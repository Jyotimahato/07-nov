package com.genpact.CMP_Automation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CmpAutomationApplicationTests {

	@Test
	void contextLoads() {
	}

}
