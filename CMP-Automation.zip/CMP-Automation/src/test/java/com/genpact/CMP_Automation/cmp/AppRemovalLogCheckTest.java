package com.genpact.CMP_Automation.cmp;

import com.genpact.CMP_Automation.utility.AirWatchLoginUtil;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

@RunWith(SpringJUnit4ClassRunner.class)
public class AppRemovalLogCheckTest {
    @Test
    public void appRemovalLogCheck() throws InterruptedException, IOException {
        WebDriverManager.chromedriver().setup();

        WebDriver driver = new ChromeDriver();
        try {
            AirWatchLoginUtil.airWatchLogin(driver);
            WebElement monitor = AirWatchLoginUtil.webDriverWait(driver).until(ExpectedConditions.elementToBeClickable(By.id("hub_mainmenu")));
            monitor.click();

            WebElement appRemovalLogs = AirWatchLoginUtil.webDriverWait(driver).until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"submenu\"]/ul[5]/li[6]/ul/li[4]/a")));
            appRemovalLogs.click();
            Thread.sleep(TimeUnit.SECONDS.toMillis(10));
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            Runtime.getRuntime().exec("taskkill /F /IM ChromeDriver.exe");
            driver.quit();
            System.exit(0);
        }

    }

}

