package com.genpact.CMP_Automation.cmp;

import com.genpact.CMP_Automation.utility.AirWatchLoginUtil;
import io.github.bonigarcia.wdm.WebDriverManager;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.IOException;

@Slf4j
@RunWith(SpringJUnit4ClassRunner.class)
public class AccConnectionTest {
    @Test
    public void accConnectionTest() throws InterruptedException, IOException {
        log.info("starting AccTestConnection");
        WebDriverManager.chromedriver().setup();
        log.info("starting AccTestConnection2");
        WebDriver driver = new ChromeDriver();
        try {
            AirWatchLoginUtil.airWatchLogin(driver);
            WebElement groupsAndSettingsElement = AirWatchLoginUtil.webDriverWait(driver).until(ExpectedConditions.elementToBeClickable(By.id("settings_mainmenu")));
            groupsAndSettingsElement.click();

            WebElement allSettings = AirWatchLoginUtil.webDriverWait(driver).until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/main/section/nav/section[2]/ul[8]/li[1]/a")));
            allSettings.click();

            WebElement system = AirWatchLoginUtil.webDriverWait(driver).until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div[5]/div[2]/section/div/div[1]/div/h2[1]/a")));
            system.click();

            WebElement enterpriseIntegration = AirWatchLoginUtil.webDriverWait(driver).until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div[5]/div[2]/section/div/div[1]/div/ul[1]/li[3]/a[2]")));
            enterpriseIntegration.click();

            WebElement cloudConnector = AirWatchLoginUtil.webDriverWait(driver).until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div[5]/div[2]/section/div/div[1]/div/ul[1]/li[3]/ul/li[3]/a")));
            cloudConnector.click();

            WebElement testConnection = AirWatchLoginUtil.webDriverWait(driver).until(ExpectedConditions.elementToBeClickable(By.name("testAccConnection")));
            testConnection.click();
            log.info("starting AccTestConnectionAfter");
            WebElement testConnectionMsg = AirWatchLoginUtil.webDriverWait(driver).until(ExpectedConditions.elementToBeClickable(By.id("testAccConnectionMessage")));
            System.out.println(testConnectionMsg.getText());
            Assert.assertTrue(testConnectionMsg.getText().contains("Reached Cloud Connector running"));

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            Runtime.getRuntime().exec("taskkill /F /IM ChromeDriver.exe");
            driver.quit();
        }

    }

}
