package com.genpact.CMP_Automation.model;

public class Notifications {
    private String notificationContent;
    private String notificationDate;

    public Notifications() {
    }

    public Notifications(String notificationContent, String notificationDate) {
        this.notificationContent = notificationContent;
        this.notificationDate = notificationDate;
    }

    public String getNotificationContent() {
        return notificationContent;
    }

    public void setNotificationContent(String notificationContent) {
        this.notificationContent = notificationContent;
    }

    public String getNotificationDate() {
        return notificationDate;
    }

    public void setNotificationDate(String notificationDate) {
        this.notificationDate = notificationDate;
    }

    @Override
    public String toString() {
        return "Notifications{" +
                "notificationContent='" + notificationContent + '\'' +
                ", notificationDate='" + notificationDate + '\'' +
                '}';
    }
}
