package com.genpact.CMP_Automation.utility;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class AirWatchLoginUtil {
    public static void airWatchLogin(WebDriver driver) {
        driver.manage().window().maximize();
        driver.get("https://cn138.awmdm.com/AirWatch/Login");

        WebElement inputElement = driver.findElement(By.id("UserName"));
        inputElement.sendKeys(System.getProperty("username"));


        WebElement clickButton = driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[2]/div/form/div[4]/input"));
        clickButton.click();
        WebElement passwordElement = webDriverWait(driver).until(ExpectedConditions.elementToBeClickable(By.id("Password")));
        passwordElement.sendKeys(System.getProperty("password"));
        WebElement loginButton = driver.findElement(By.name("Login"));
        loginButton.click();
    }
    public static WebDriverWait webDriverWait(WebDriver driver) {
        return new WebDriverWait(driver, Duration.ofSeconds(20));
    }
}
