package com.genpact.CMP_Automation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CmpAutomationApplication {

	public static void main(String[] args) {
		SpringApplication.run(CmpAutomationApplication.class, args);
	}

}
